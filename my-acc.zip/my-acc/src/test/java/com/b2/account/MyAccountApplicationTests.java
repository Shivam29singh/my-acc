package com.b2.account;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyAccountApplicationTests {

	@Test
	void contextLoads() {
	}

}
