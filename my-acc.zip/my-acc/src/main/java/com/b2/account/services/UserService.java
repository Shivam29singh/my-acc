package com.b2.account.services;

import com.b2.account.model.User;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

public interface UserService {

    List<User> getAllUsers();

    Optional<User> getUserById(Integer userId);

    String addNewUser(User user);

    Boolean exists(Integer userId);

}
