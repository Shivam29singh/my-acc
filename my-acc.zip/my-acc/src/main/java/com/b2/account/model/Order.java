package com.b2.account.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonAppend;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.TypeAlias;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;
import java.util.Date;

@Document(collection = "Order")
@TypeAlias("Order")
public class Order {

    @Id
    private Integer orderId;

    @Field("orderPlacedDate")
    private Date orderPlacedDate;

    @Field("status")
    private  String status;

    @Field("paymentStatus")
    private String paymentStatus;

    @Field("customerInfo")
    @JsonProperty("customerInfo")
    private CustomerInfo customerInfo;

    @Field("orderPriceInfo")
    @JsonProperty("orderPriceInfo")
    private OrderPriceInfo orderPriceInfo;

    @Field("lineItems")

    @JsonProperty("lineItems")
    private LineItems lineItems;

    @Field("payments")

    @JsonProperty("payments")
    private Payments payments;

    @Field("shipAddr")
    @JsonProperty("shipAddr")
    private ShipAddr shipAddr;

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public Date getOrderPlacedDate() {
        return orderPlacedDate;
    }

    public void setOrderPlacedDate(Date orderPlacedDate) {
        this.orderPlacedDate = orderPlacedDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public OrderPriceInfo getOrderPriceInfo() {
        return orderPriceInfo;
    }

    public void setOrderPriceInfo(OrderPriceInfo orderPriceInfo) {
        this.orderPriceInfo = orderPriceInfo;
    }

    public LineItems getLineItems() {
        return lineItems;
    }

    public void setLineItems(LineItems lineItems) {
        this.lineItems = lineItems;
    }

    public Payments getPayments() {
        return payments;
    }

    public void setPayments(Payments payments) {
        this.payments = payments;
    }

    public ShipAddr getShipAddr() {
        return shipAddr;
    }

    public void setShipAddr(ShipAddr shipAddr) {
        this.shipAddr = shipAddr;
    }

    public CustomerInfo getCustomerInfo() {
        return customerInfo;
    }

    public void setCustomerInfo(CustomerInfo customerInfo) {
        this.customerInfo = customerInfo;
    }

    public Order(Integer orderId, Date orderPlacedDate, String status, String paymentStatus, CustomerInfo customerInfo, OrderPriceInfo orderPriceInfo, LineItems lineItems, Payments payments, ShipAddr shipAddr) {
        this.orderId = orderId;
        this.orderPlacedDate = orderPlacedDate;
        this.status = status;
        this.paymentStatus = paymentStatus;
        this.customerInfo = customerInfo;
        this.orderPriceInfo = orderPriceInfo;
        this.lineItems = lineItems;
        this.payments = payments;
        this.shipAddr = shipAddr;
    }

    public Order() {
    }

    @Override
    public String toString() {
        return "Order{" +
                "orderId=" + orderId +
                ", orderPlacedDate=" + orderPlacedDate +
                ", status='" + status + '\'' +
                ", paymentStatus='" + paymentStatus + '\'' +
                ", customerInfo=" + customerInfo +
                ", orderPriceInfo=" + orderPriceInfo +
                ", lineItems=" + lineItems +
                ", payments=" + payments +
                ", shipAddr=" + shipAddr +
                '}';
    }
}
