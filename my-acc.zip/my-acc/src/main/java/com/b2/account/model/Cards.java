package com.b2.account.model;


import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.TypeAlias;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection = "Cards")
@TypeAlias("Cards")
public class Cards {


    @Id
    private Integer user_id;

    @Field("cardid")
    private Integer card_id;

    @Field("cardnumber")
    private String cardNumber;

    @Field("name")
    private String name;

    @Field("validity")
    private String validity ;

    @Field("maskedcardnumber")
     private String maskedcardno ;

    @Field("cardtype")
     private String cardType;

    public Cards() {
    }

    public Cards(Integer user_id, Integer card_id, String cardNumber, String name, String validity, String maskedcardno, String cardType) {
        this.user_id = user_id;
        this.card_id = card_id;
        this.cardNumber = cardNumber;
        this.name = name;
        this.validity = validity;
        this.maskedcardno = maskedcardno;
        this.cardType = cardType;
    }


    @Override
    public String toString() {
        return "Cards{" +
                "user_id=" + user_id +
                ", card_id=" + card_id +
                ", cardNumber='" + cardNumber + '\'' +
                ", name='" + name + '\'' +
                ", validity='" + validity + '\'' +
                ", maskedcardno='" + maskedcardno + '\'' +
                ", cardType='" + cardType + '\'' +
                '}';
    }

    public Integer getUser_id() {
        return user_id;
    }

    public void setUser_id(Integer user_id) {
        this.user_id = user_id;
    }

    public Integer getCard_id() {
        return card_id;
    }

    public void setCard_id(Integer card_id) {
        this.card_id = card_id;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getValidity() {
        return validity;
    }

    public void setValidity(String validity) {
        this.validity = validity;
    }

    public String getMaskedcardno() {
        return maskedcardno;
    }

    public void setMaskedcardno(String maskedcardno) {
        this.maskedcardno = maskedcardno;
    }

    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }
}
