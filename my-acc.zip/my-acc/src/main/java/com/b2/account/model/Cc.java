package com.b2.account.model;


import com.fasterxml.jackson.annotation.JsonProperty;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.TypeAlias;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection = "Cc")
@TypeAlias("Cc")
public class Cc {
    @Id
        private Integer id;

    @Field("token")
    private String token;

    @Field("last4")
    private String last4;

    @Field("type")
    private String type;

    @Field("expiryMonth")
    private Integer expiryMonth;

    @Field("expiryYear")
    private Integer expiryYear;

    @Field("billAddr")
    @JsonProperty("billAddr")
    private BillAddr billAddr;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getLast4() {
        return last4;
    }

    public void setLast4(String last4) {
        this.last4 = last4;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Integer getExpiryMonth() {
        return expiryMonth;
    }

    public void setExpiryMonth(Integer expiryMonth) {
        this.expiryMonth = expiryMonth;
    }

    public Integer getExpiryYear() {
        return expiryYear;
    }

    public void setExpiryYear(Integer expiryYear) {
        this.expiryYear = expiryYear;
    }

    public BillAddr getBillAddr() {
        return billAddr;
    }

    public void setBillAddr(BillAddr billAddr) {
        this.billAddr = billAddr;
    }

    public Cc(Integer id, String token, String last4, String type, Integer expiryMonth, Integer expiryYear, BillAddr billAddr) {
        this.id = id;
        this.token = token;
        this.last4 = last4;
        this.type = type;
        this.expiryMonth = expiryMonth;
        this.expiryYear = expiryYear;
        this.billAddr = billAddr;
    }

    public Cc() {
    }

    @Override
    public String toString() {
        return "Cc{" +
                "id=" + id +
                ", token='" + token + '\'' +
                ", last4='" + last4 + '\'' +
                ", type='" + type + '\'' +
                ", expiryMonth=" + expiryMonth +
                ", expiryYear=" + expiryYear +
                ", billAddr=" + billAddr +
                '}';
    }
}
