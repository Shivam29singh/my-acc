package com.b2.account.resource;

public class CardsResource {
}
