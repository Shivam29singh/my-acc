package com.b2.account.resource;


import com.b2.account.model.Order;
import com.b2.account.services.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/api/order")
public class OrderResource {

    @Autowired
    OrderService orderService;

    @PostMapping(value="/addOrder")
    public String newUser(@RequestBody Order order) {
        return orderService.addNewOrder(order);
    }

    @GetMapping(value="/getorders")
    public List<Order> getOrders()
    {
        System.out.println(orderService.getAllOrders());
         return orderService.getAllOrders();
    }
}
