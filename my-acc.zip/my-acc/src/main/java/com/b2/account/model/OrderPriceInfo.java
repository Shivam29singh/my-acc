package com.b2.account.model;


import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.TypeAlias;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection = "OrderPriceInfo")
@TypeAlias("OrderPriceInfo")
public class OrderPriceInfo {

    @Id
    private Integer orderPriceInfoId;

    @Field("totalItemAmount")
    private Integer totalItemAmount;

    @Field("totalShippingAmount")
    private Integer totalShippingAmount;

    @Field("finalOrderPrice")
    private Integer finalOrderPrice;

    public Integer getOrderPriceInfoId() {
        return orderPriceInfoId;
    }

    public void setOrderPriceInfoId(Integer orderPriceInfoId) {
        this.orderPriceInfoId = orderPriceInfoId;
    }

    public Integer getTotalItemAmount() {
        return totalItemAmount;
    }

    public void setTotalItemAmount(Integer totalItemAmount) {
        this.totalItemAmount = totalItemAmount;
    }

    public Integer getTotalShippingAmount() {
        return totalShippingAmount;
    }

    public void setTotalShippingAmount(Integer totalShippingAmount) {
        this.totalShippingAmount = totalShippingAmount;
    }

    public Integer getFinalOrderPrice() {
        return finalOrderPrice;
    }

    public void setFinalOrderPrice(Integer finalOrderPrice) {
        this.finalOrderPrice = finalOrderPrice;
    }

    public OrderPriceInfo(Integer orderPriceInfoId, Integer totalItemAmount, Integer totalShippingAmount, Integer finalOrderPrice) {
        this.orderPriceInfoId = orderPriceInfoId;
        this.totalItemAmount = totalItemAmount;
        this.totalShippingAmount = totalShippingAmount;
        this.finalOrderPrice = finalOrderPrice;
    }

    public OrderPriceInfo() {
    }

    @Override
    public String toString() {
        return "OrderPriceInfo{" +
                "orderPriceInfoId=" + orderPriceInfoId +
                ", totalItemAmount=" + totalItemAmount +
                ", totalShippingAmount=" + totalShippingAmount +
                ", finalOrderPrice=" + finalOrderPrice +
                '}';
    }
}
