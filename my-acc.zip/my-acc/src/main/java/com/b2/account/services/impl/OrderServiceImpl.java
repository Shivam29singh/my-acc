package com.b2.account.services.impl;

import com.b2.account.dao.OrderDao;
import com.b2.account.model.Order;
import com.b2.account.services.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrderServiceImpl implements OrderService
{
    @Autowired
    OrderDao orderDao;

    public void setOrderDao(OrderDao orderDao)
    {
        this.orderDao = orderDao;
    }
    @Override

    public List<Order> getAllOrders()
    {
        return orderDao.findAll();
    }

    @Override
    public String addNewOrder(Order order) {
        orderDao.save(order);
        return "Order Added Successfully";
    }
}
