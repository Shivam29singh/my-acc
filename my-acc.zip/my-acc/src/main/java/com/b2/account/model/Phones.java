package com.b2.account.model;


import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.TypeAlias;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection = "Phones")
@TypeAlias("Phones")
public class Phones {

    @Id
    private Integer phoneId;

    @Field("type")
    private String type;

    @Field("num")
    private String num;

    public Integer getPhoneId() {
        return phoneId;
    }

    public void setPhoneId(Integer phoneId) {
        this.phoneId = phoneId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public Phones(Integer phoneId, String type, String num) {
        this.phoneId = phoneId;
        this.type = type;
        this.num = num;
    }

    public Phones() {
    }

    @Override
    public String toString() {
        return "Phones{" +
                "phoneId=" + phoneId +
                ", type='" + type + '\'' +
                ", num='" + num + '\'' +
                '}';
    }
}
