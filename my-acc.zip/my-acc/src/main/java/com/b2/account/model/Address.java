package com.b2.account.model;


import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.TypeAlias;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection = "Address")
@TypeAlias("Address")
public class Address {


    @Id
    private Integer user_id;


    @Field("address_id")
    private Integer address_id;

    @Field("city")
    private String city;


    @Field("state")
    private String state;


    @Field("zipcode")
    private Integer zipcode;

    @Field("country")
    private String country;

    @Field("housenumber")
    private Integer houseNumber;

    @Field("Street")
    private String street ;

    @Field("landmark")
    private String landmark;


    public Address() {
    }

    public Address(Integer user_id, Integer address_id, String city, String state, Integer zipcode, String country, Integer houseNumber, String street, String landmark) {
        this.user_id = user_id;
        this.address_id = address_id;
        this.city = city;
        this.state = state;
        this.zipcode = zipcode;
        this.country = country;
        this.houseNumber = houseNumber;
        this.street = street;
        this.landmark = landmark;
    }

    @Override
    public String toString() {
        return "Address{" +
                "user_id=" + user_id +
                ", address_id=" + address_id +
                ", city='" + city + '\'' +
                ", state='" + state + '\'' +
                ", zipcode=" + zipcode +
                ", country='" + country + '\'' +
                ", houseNumber=" + houseNumber +
                ", street='" + street + '\'' +
                ", landmark='" + landmark + '\'' +
                '}';
    }

    public Integer getUser_id() {
        return user_id;
    }

    public void setUser_id(Integer user_id) {
        this.user_id = user_id;
    }

    public Integer getAddress_id() {
        return address_id;
    }

    public void setAddress_id(Integer address_id) {
        this.address_id = address_id;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public Integer getZipcode() {
        return zipcode;
    }

    public void setZipcode(Integer zipcode) {
        this.zipcode = zipcode;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public Integer getHouseNumber() {
        return houseNumber;
    }

    public void setHouseNumber(Integer houseNumber) {
        this.houseNumber = houseNumber;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getLandmark() {
        return landmark;
    }

    public void setLandmark(String landmark) {
        this.landmark = landmark;
    }
}
